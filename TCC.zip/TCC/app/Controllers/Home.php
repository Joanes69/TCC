<?php

namespace App\Controllers;

class Home extends BaseController
{

    public function index()
    {
        echo view ('Template/header');
        echo view('home');
        echo view('Template/footer');
    }


    public function login(){
        $erros = '';

        $msg = '';

        // o array $_POST tem algum item?
        // ou seja: foi enviado algo via POST?
        if ( count($_POST) > 0 ) {

            // encurta o $_POST para $p para facilitar
            $p = $_POST;

            // se o campo usu_email n veio no post ou se veio mas não tem valor nenhum, entao erro
            if ( !isset($p['usu_email']) || !$p['usu_email'] ) {

                $erros .= 'E-mail faltando ou inválido.<br />';

            }

            // se o campo usu_senha n veio no post ou se veio mas tem menos de 8 caracteres, entao erro
            if ( !isset($p['usu_email']) || strlen($p['usu_email']) < 8 ) {

                $erros .= 'E-mail faltando ou inválido.<br />';

            }

            // se NAO temos erros
            if ( !$erros ) {

                

                // extrai o email e a senha
                $email = $p['usu_email'];
                $senha = $p['usu_senha'];

                // comando a ser executado
                $sql = "SELECT * FROM usuarios WHERE usu_email = '$email' AND usu_senha='$senha'";

                // executa o comando no BD e guarda o resultado em $result
                $result = $this->db->query( $sql );

                // acessa a unica linha que deve ter no result ou NADA se nao deu certo
                $usuario = $result->getRowArray();

                // se $usuario == NULL, entao n foi encontrado o usuario no BD com o email e senha informados
                if ($usuario == null) $erros .= 'Verifique o e-mail e a senha informados.<br />';

                else {

                    // caso contrario... deu certo!
                    $msg = 'OK! Entrando...';

                    // print_r($usuario['usu_email']);

                    // iniciar sessao e gravar sessao

                    // redirecionar o usuario...

                }

            }

        }

        // carrega a view login, passando 2 dados para a tela
            // a var $erros com possíveis erros ocorridos
            // a var $msg com a mensagem de sucesso (caso exista)
        echo view('login', [ 'erros' => $erros, 'msg' => $msg ] );    
    }
    public function cadastro() {
		
		$msg = '';
		$erros = '';
		
        if ( count($_POST) > 0 ) {

            $p = $_POST;
			
			// validando o nome
            if ( !isset($p['usu_name']) || !$p['usu_name'] ) {

                $erros .= 'Digite o nome.<br />';

            }

            // se o campo usu_email n veio no post ou se veio mas não tem valor nenhum, entao erro
            if ( !isset($p['usu_email']) || !$p['usu_email'] ) {

                $erros .= 'E-mail faltando ou inválido.<br />';

            }

            // se o campo usu_senha n veio no post ou se veio mas tem menos de 8 caracteres, entao erro
            if ( !isset($p['usu_senha']) || strlen($p['usu_senha']) < 8 ) {

                $erros .= 'Senha faltando, ou tem menos de 8 chars ou inválida.<br />';

            }

            // se NAO temos erros
            if ( !$erros ) {

                // extrai o email e a senha
				$nome = $p['usu_name'];
                $email = $p['usu_email'];
				
                $senha = $p['usu_senha'] ;

                // comando a ser executado
                $sql = "INSERT INTO usuarios VALUES (null,'$nome','$email','$senha')";

                // executa o comando no BD
                $this->db->query( $sql );
			
                if ( $this->db->error()['message'] ) {
					$erros .= $this->db->error()['message'];
				} else {
					$msg .= 'Cadastrado com sucesso!';
				}

            }

        }
        echo view('cadastro', [ 'erros' => $erros, 'msg' => $msg ] );
    }
    
    
    
		
}

