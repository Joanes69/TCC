
   
        <div class=" bg-dark bg-expanded text-light p2 text-center">
                   <p> Logo Projeto</p>
                    <p>
                          Contato      
                    </p>
                    <p>
                        Instagram
                    </p>
                    <p>
                        Facebook
                    </p>
                    <span>
                        Email
                    </span>
    
        </div>

</body>
</html>